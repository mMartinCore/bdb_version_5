<script language="javascript">

        if ( $(window).width() >= 1280 && $(window).width() <= 1440) {
             document.write("<style>body{zoom:90%;}</style>");
         }
        else if ( $(window).width()> =1080   && $(window).width() < 1280) {
            document.write("<style>body{zoom:75%;}</style>");
        }
        else if ( $(window).width()>=750  && $(window).width() < 1080 ) {
            document.write("<style>body{zoom:65%;}</style>");
        }
        else if ( $(window).width() < 750 ) {
            document.write("<style>body{zoom:50%;}</style>");
        }
  </script>

 


<script language="javascript">
 document.write("<style>body{zoom:90%;}</style>");






 




 
/*
UPDATE `corpses` SET  `pauper_burial_requested`= "No",`pauper_burial_requested_date`= null ,`pauper_burial_approved`="No-Request",
`pauper_burial_approved_date`=null,`buried`="No",`burial_date`=null;



 UPDATE `corpses` SET  `pauper_burial_requested`= "Yes",`pauper_burial_requested_date`= "2020-02-15" ,`pauper_burial_approved`="Processing",
`pauper_burial_approved_date`=null,`buried`="No",`burial_date`=null;
*/


 </script>



