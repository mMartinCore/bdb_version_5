




    <div class="container">
    <br><br>







        <div class="panel panel-primary">

{{-- <div class="panel-heading">  Statistic
    <div class=" pull-right">
        <select name="" class=" chart form-control" id="chart">
            <option value=""> Select chart type </option>
            <option value="pie">Pie Chart

            </option>
            <option value="bar">
                    Bar Chart
            </option>
            <option value="donut">Donut Chart</option>
        </select>
    </div> --}}
       </div>



       <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>{!!$overThirtyDays!!}</h3>

              <p> Bodies Over 30 Days</p>
            </div>
            <div class="icon">
                <i class="fa fa-calendar" aria-hidden="true"></i>
            </div>
            <a href="#" class="small-box-footer">  <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
            <h3> {!!$post_mortem_pending!!}<sup style="font-size: 20px"></sup></h3>

              <p> Post Mortem Pending</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer"> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
            <h3>{!!$burial_request!!}</h3>

              <p> Burial Request</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="{!! route('corpses.approve') !!}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-purple">
            <div class="inner">
            <h3> {!!$burial_NotApproved!!}</h3>

              <p> Burial Not Approved</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="{!! route('corpses.notApprove') !!}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>




            <div class="panel-body">
                <div class="row">
                        <div class="col-sm-6">
                        {!! $chart->html() !!}
                        </div>
                        <div class="col-sm-6">
                            {!! $bar->html() !!}
                        </div>
                </div>

<hr>
                <div class="row">
                    <div class="col-sm-6">
                    {!! $pie->html() !!}
                    </div>
                    <div class="col-sm-6">
                        {!! $notApproved_bar->html() !!}
                    </div>
            </div>

            </div>

    </div>
</div>

    {!! Charts::scripts() !!}
    {!! $chart->script() !!}
    {!! $bar->script() !!}
    {!! $pie->script() !!}
    {!! $notApproved_bar->script() !!}

<script>
    $(document).ready(function(){

    var chart='';
    $("select.chart").change(function(){
        chart= $(this).children("option:selected").val();

  if (chart=='pie') {
    location. replace("/leaves/leaveStats/0/pie");
  } if (chart=='bar') {
    location. replace("/leaves/leaveStats/0/bar");
  }  if (chart=='donut') {
    location. replace("/leaves/leaveStats/0/donut");
  }


    });
});

</script>
 
