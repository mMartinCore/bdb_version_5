@extends('layouts.app')
@section('title', '| Permissions')

@section('content')



 <section  class="content-header">


        <h4 class="dasboard"><span><i class="	glyphicon glyphicon-dashboard"></i></span> Dashboard </h4>
      </section>
  @include('/dashboard')
@endsection
