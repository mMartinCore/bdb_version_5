Good day <strong>{{ $name }}</strong>,

<p>{{ $body }}</p><br><br>


<small style="color:royalblue">
      JCF Innovation Business System Unit (IBSU) <br>
      101-106 Old Hope Road <br>
      Kingston 6 <br>
      Tel: 876- 927-4597


</small> <br>
<small style="color:red">
      This email was automatically generated, please do not reply.
<small>
