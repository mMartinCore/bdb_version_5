
@foreach ($mark as $a)
{{$a}}
@endforeach
