<?php 

namespace App\Exceptions;

class customException extends \Exception{};
?>
