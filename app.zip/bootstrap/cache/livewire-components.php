<?php return array (
  'message-admin' => 'App\\Http\\Livewire\\MessageAdmin',
);